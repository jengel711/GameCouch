package com.gamecouch.gcs.gamecouchsystem;

public interface PersistedData {
//currently does nothing except allow use of Lookup methods, which I am in the process of making generic - AB
	
	
	

}
