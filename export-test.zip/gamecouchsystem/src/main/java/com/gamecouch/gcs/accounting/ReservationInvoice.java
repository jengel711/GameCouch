/**
 * 
 */
package com.gamecouch.gcs.accounting;




/**
 * @author Alan Bolte
 *
 */
public class ReservationInvoice extends Invoice {
	//private Reservation reservation;
	
	
	
	
	
}
